import{I as o,D as r,L as s}from"./Dragger-53e4e55c.js";const a=o;a.Dragger=r;a.LIST_IGNORE=s;const p=a;export{p as U};
